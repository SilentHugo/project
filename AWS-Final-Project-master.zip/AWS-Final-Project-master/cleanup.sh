aws cloudformation delete-stack --stack-name $STACK_NAME
sleep 10
